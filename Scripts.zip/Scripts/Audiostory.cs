﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Audiostory : MonoBehaviour {
    public AudioSource Why;
    public AudioSource sacrifice;
	// Use this for initialization
	void Start () {
        Why.PlayDelayed(4.7f);
        sacrifice.PlayDelayed(9.8f);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
