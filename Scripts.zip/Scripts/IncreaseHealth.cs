﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IncreaseHealth : MonoBehaviour {
    private void OnMouseDown()
    {
        Stats.health = Stats.health + 1;
        Points.skillsDecrease = Points.skillsDecrease + 1;
    }
}
