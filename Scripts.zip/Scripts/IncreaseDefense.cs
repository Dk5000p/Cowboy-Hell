﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IncreaseDefense : MonoBehaviour {

    private void OnMouseDown()
    {
        Stats.defense = Stats.defense + 1;
        Points.skillsDecrease = Points.skillsDecrease + 1;
    }
}

