﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DamageUp : MonoBehaviour {
    private void OnMouseDown()
    {
        Stats.damage = Stats.damage + 1;
        Points.skillsDecrease = Points.skillsDecrease + 1;
    }
}
