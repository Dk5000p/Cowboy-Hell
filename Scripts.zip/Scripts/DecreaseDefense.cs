﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DecreaseDefense : MonoBehaviour {

    private void OnMouseDown()
    {
        if (Points.skillsDecrease != 0 && Stats.defense > 1)
        {
            Stats.defense = Stats.defense - 1;
            Points.skillsDecrease = Points.skillsDecrease - 1;
        }
    }
}
