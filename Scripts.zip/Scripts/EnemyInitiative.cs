﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EnemyInitiative : MonoBehaviour {
    public static int initiative;
    public  int speed;
    public  int attack;
    public  int damage;
    public int health;
    public int defense;
    public Text Enemy;
    public int attackRole;
    public int attackRole2;
    public static bool Alive;
    public float Timer;
    public AudioSource dead;
    public Slider HealthBar;
    public AudioSource Missed;
    public AudioSource Hit;
	// Use this for initialization
	void Start () {
        initiative = Random.Range(1, 20);
        initiative = initiative + speed;
        Debug.Log("Enemyinitiative:"+initiative);
        Alive = true;
	}

    // Update is called once per frame
    void Update() {
        Enemy.text = "Enemy Initiative: " + initiative.ToString();
        HealthBar.value = health;
        Debug.Log("Defense" + defense);
        if (RollDice.yourTurn == false && Alive == true)
        {
            attackRole2 = Random.Range(1, 20);
            attackRole = attackRole2 + attack;
            Timer += Time.deltaTime;
            if (attackRole > Stats.defense && Timer >= 1f) {
                Hit.Play();
                Stats.health = Stats.health - damage;
                RollDice.yourTurn = true;
                Timer = 0;
            }else if (attackRole2 == 20 && Timer >= 1f)
            {
                Hit.Play();
                Stats.health = Stats.health - damage;
                RollDice.yourTurn = true;
                Timer = 0;
            }
        else if (attackRole <= Stats.defense && Alive == true && Timer >= 1f)
        {

            Missed.Play();
            RollDice.yourTurn = true;
            Timer = 0;
        }

            if (health <= 0)
            {
                Alive = false;
                RollDice.yourTurn = true;
                dead.Play();
                Points.skillsDecrease = 5;
            }
        }
	}
}
