﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DecreaseDamage : MonoBehaviour {
    private void OnMouseDown()
    {
        if (Points.skillsDecrease != 0 && Stats.damage > 1)
        {
            Stats.damage = Stats.damage - 1;
            Points.skillsDecrease = Points.skillsDecrease - 1;
        }
    }
}
