﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IncreaseSpeed : MonoBehaviour {

    private void OnMouseDown()
    {
        Stats.speed = Stats.speed + 1;
        Points.skillsDecrease = Points.skillsDecrease + 1;
    }
}
