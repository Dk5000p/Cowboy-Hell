﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IncreaseAttack : MonoBehaviour {

    private void OnMouseDown()
    {
        Stats.attack = Stats.attack + 1;
        Points.skillsDecrease = Points.skillsDecrease + 1;
    }
}
