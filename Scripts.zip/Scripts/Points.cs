﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Points : MonoBehaviour {
    public static int skillsDecrease;
    public Text SkillPoints;
	// Use this for initialization
	void Start () {
        skillsDecrease = 5;
	}
	
	// Update is called once per frame
	void Update () {
        SkillPoints.text = "You need to decrease " + skillsDecrease.ToString() + " Skill(s)";
	}
}
