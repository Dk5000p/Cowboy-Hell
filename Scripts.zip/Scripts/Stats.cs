﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Stats : MonoBehaviour {
    public static int health;
    public static int attack;
    public static int damage;
    public static int speed;
    public static int defense;
    public Text AttackAmount;
    public Text HealthAmount;
    public Text DamageAmount;
    public Text SpeedAmount;
    public Text DefenseAmount;

	// Use this for initialization
	void Start () {
        health = 100;
        attack = 10;
        damage = 10;
        speed = 10;
        defense = 15;
	}
	
	// Update is called once per frame
	void Update () {
        HealthAmount.text = "Health: " + health.ToString();
        AttackAmount.text = "Attack: " + attack.ToString();
        DamageAmount.text = "Damage: " + damage.ToString();
        SpeedAmount.text = "Speed: " + speed.ToString();
        DefenseAmount.text = "Defense: " + defense.ToString();
        Debug.Log("Stats Attack" + attack);
        if (Stats.health <= 0)
        {
            health = 100;
            SceneManager.LoadScene(4);
        }
    }
}
