﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class RollDice : MonoBehaviour {
    public int DiceRoll;
    public int AttackRoll;
    public Text RoleValue;
    public Text YourInitiativeText;
    public bool initiativeTurn;
    public Text turn;
    public static bool yourTurn;
    public int yourInitiative;
    public GameObject targetGameObject;
    public AudioSource Missed;
    public float Timer;
    public int defense;
    public int AttackValue;
    public AudioSource CriticalHit;
    public GameObject bullet;
    public Transform player;
    // Use this for initialization
    void Start() {
        yourTurn = false;
        initiativeTurn = true;

        if (initiativeTurn == true)
        {
            DiceRoll = Random.Range(1, 20);
            yourInitiative = DiceRoll + Stats.speed;
            YourInitiativeText.text = "Your Initiative: " + yourInitiative.ToString();



            if (yourInitiative >= EnemyInitiative.initiative && initiativeTurn == true)
            {
                yourTurn = true;
                initiativeTurn = false;


            }
            else if (yourInitiative < EnemyInitiative.initiative && initiativeTurn == true)
            {
                yourTurn = false;
                initiativeTurn = false;

            }

        }

    }
	
	// Update is called once per frame
	void Update () {
        defense = targetGameObject.GetComponent<EnemyInitiative>().defense;
        RoleValue.text = DiceRoll.ToString();
        AttackValue = Stats.attack;
      
        if (yourTurn == true)
        {
            turn.text = "Your Turn";
        } else if (initiativeTurn == true&&yourTurn==false)
        {
            turn.text = "Initiative Turn";
        }else if (yourTurn == false)
        {
            turn.text = "Enemy Turn";
        }
	}
    private void OnMouseDown()
    {
       
        
            if (yourTurn == true)
        {
            DiceRoll = Random.Range(1, 20);
            AttackRoll = DiceRoll + AttackValue;
            Instantiate(bullet, player.position, Quaternion.identity);
            Debug.Log("Attack Value"+AttackRoll);
            if(AttackRoll>defense&&AttackRoll-defense<=9)
            {
                Debug.Log(DiceRoll);
                targetGameObject.GetComponent<EnemyInitiative>().health = targetGameObject.GetComponent<EnemyInitiative>().health-Stats.damage;
                Debug.Log(targetGameObject.GetComponent<EnemyInitiative>().health);
                yourTurn = false;
            }else if(AttackRoll > defense && AttackRoll - defense > 9)
            {
                CriticalHit.Play();
                targetGameObject.GetComponent<EnemyInitiative>().health = targetGameObject.GetComponent<EnemyInitiative>().health - Stats.damage*2;
                yourTurn = false;
            }
            else if (AttackRoll <= defense)
            {
                Missed.Play();
                yourTurn = false;
            }
            else if (DiceRoll == 20)
            {
                targetGameObject.GetComponent<EnemyInitiative>().health = targetGameObject.GetComponent<EnemyInitiative>().health - Stats.damage;
            }


        }
       
            }
        }
    

