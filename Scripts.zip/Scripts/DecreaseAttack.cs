﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DecreaseAttack : MonoBehaviour {
    private void OnMouseDown()
    {
        if (Points.skillsDecrease != 0&&Stats.attack>1)
        {
            Stats.attack = Stats.attack - 1;
            Points.skillsDecrease = Points.skillsDecrease - 1;
        }
    }
}
