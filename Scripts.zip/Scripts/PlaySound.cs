﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlaySound : MonoBehaviour {
    public AudioSource sound;
	// Use this for initialization
	void Start () {
        sound.PlayDelayed(3.85f);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
