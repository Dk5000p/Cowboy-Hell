﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Destroy : MonoBehaviour {

	// Use this for initialization
	void Start () {
        Destroy(gameObject, 4.7f);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
