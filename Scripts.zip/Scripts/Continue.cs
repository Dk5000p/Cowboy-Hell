﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Continue : MonoBehaviour {
    public int scene;
    private void OnMouseDown()
    {
        if (Points.skillsDecrease == 0)
        {
            SceneManager.LoadScene(scene);
        }
    }
}
