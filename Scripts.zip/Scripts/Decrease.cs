﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Decrease : MonoBehaviour {

    private void OnMouseDown()
    {
        if (Points.skillsDecrease != 0&&Stats.health > 1)
        {
            Stats.health = Stats.health - 1;
            Points.skillsDecrease = Points.skillsDecrease - 1;
        }
    }
}
