﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TurnRed : MonoBehaviour {

    SpriteRenderer m_SpriteRenderer;
    private void Start()
    {
        m_SpriteRenderer = GetComponent<SpriteRenderer>();
        //Set the GameObject's Color quickly to a set Color (blue)
        ;
    }
    private void OnMouseEnter()
    {
        m_SpriteRenderer.color = Color.red;
    }
    private void OnMouseExit()
    {
        m_SpriteRenderer.color = Color.white;
    }
}
