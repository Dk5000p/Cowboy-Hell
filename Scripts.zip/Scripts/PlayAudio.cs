﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayAudio : MonoBehaviour {
    public AudioSource choices;
	// Use this for initialization
	void Start () {
        choices.PlayDelayed(40f);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
