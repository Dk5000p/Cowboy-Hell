﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AppearAfterTimer : MonoBehaviour {
    public float Timer;
    public float timePassed;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        Timer += Time.deltaTime;
        if (Timer >=timePassed) {
            gameObject.transform.GetChild(0).gameObject.SetActive(true);
        }
    }
}
