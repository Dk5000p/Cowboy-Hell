﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DecreaseSpeed : MonoBehaviour {
    private void OnMouseDown()
    {
        if (Points.skillsDecrease != 0 && Stats.speed > 1)
        {
            Stats.speed = Stats.speed - 1;
            Points.skillsDecrease = Points.skillsDecrease - 1;
        }
    }
}
